package com.grocerymart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class groceryApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(groceryApplication.class, args);
		
		System.out.println("App Started...");
	}


}
