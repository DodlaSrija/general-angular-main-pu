package com.grocerymart.modal;

public enum OrderStatus {
	PAID
}
