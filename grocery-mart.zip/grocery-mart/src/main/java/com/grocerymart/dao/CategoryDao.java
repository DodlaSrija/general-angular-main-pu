package com.grocerymart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocerymart.modal.Category;

public interface CategoryDao extends JpaRepository<Category, Long>  {

}
