package com.grocerymart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocerymart.modal.OrderProduct;

public interface OrderProductDao extends JpaRepository<OrderProduct, Long> {

}
