package com.grocerymart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocerymart.modal.Order;

public interface OrderDao extends JpaRepository<Order, Long> {

}
