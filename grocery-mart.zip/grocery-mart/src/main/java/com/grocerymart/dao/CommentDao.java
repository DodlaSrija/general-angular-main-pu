package com.grocerymart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocerymart.modal.Comment;

public interface CommentDao extends JpaRepository<Comment, Long> {

}
